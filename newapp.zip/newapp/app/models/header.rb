class Header < ActiveRecord::Base

end
