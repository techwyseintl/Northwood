# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '49d72292779337ef15b245f0de3b744a99b8fcf05c6f5c0fa43c9fb9602507e6c9a6db16bf04a1c7dc0eccf2e5d728d95f44d8bf35655d7534b8726f49a38e5d';
