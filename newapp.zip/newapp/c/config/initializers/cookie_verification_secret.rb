# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '982f719c3852aac03027318713678f52fd494d1c2b286ee770be4fef67572145beefb245f4bf0722844534e2dd6e469f1d43dab5ca0a74bd343d809ac6ad986d';
