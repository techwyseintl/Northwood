require File.dirname(__FILE__) + '/../test_helper'

class NewsletterIssueTest < Test::Unit::TestCase
  fixtures :newsletter_issues

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
