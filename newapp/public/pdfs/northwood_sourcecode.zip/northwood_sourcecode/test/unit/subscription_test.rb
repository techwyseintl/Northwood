require File.dirname(__FILE__) + '/../test_helper'

class SubscriptionTest < Test::Unit::TestCase
  fixtures :subscriptions

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
